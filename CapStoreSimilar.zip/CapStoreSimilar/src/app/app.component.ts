import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'CapStore';

  constructor(private router: Router) {

  }
  viewSimilar() {
    // navigate to home page on click of Go to Home button
    this.router.navigate(['similar-product']);
 }

}
